package com.food.receipesAndIngredientManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipesAndIngredientManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipesAndIngredientManagementApplication.class, args);
	}

}
