package com.profile.userProfileManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProfileManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
