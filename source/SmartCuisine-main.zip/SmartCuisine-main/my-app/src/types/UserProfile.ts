export interface UserProfile {
    username: string;
    email: string;
    gender: string;
    notifications?: Notification[];
  }