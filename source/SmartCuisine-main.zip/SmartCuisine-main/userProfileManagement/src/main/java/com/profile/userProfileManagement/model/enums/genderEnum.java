package com.profile.userProfileManagement.model.enums;

public enum genderEnum {
    Male,
    Female
}
