export interface Notification {
    notificationId: number;
    content: string;
  }