CREATE DATABASE userProfile_db;
CREATE DATABASE shoppingList_db;
CREATE DATABASE ingredientsStorage_db;
CREATE DATABASE recipesAndIngredient_db;
CREATE DATABASE notification_db;