# SmartCuisine
Project for the course of Laboratory of Advanced Programming of Engineering in Computer Science Master's degree at Università La Sapienza.
