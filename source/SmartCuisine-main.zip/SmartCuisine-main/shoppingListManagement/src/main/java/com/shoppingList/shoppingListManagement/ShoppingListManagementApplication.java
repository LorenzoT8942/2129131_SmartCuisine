package com.shoppingList.shoppingListManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingListManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingListManagementApplication.class, args);
	}

}
